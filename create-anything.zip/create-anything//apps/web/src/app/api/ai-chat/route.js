export async function POST(request) {
  try {
    const { message } = await request.json();

    // Mock AI response - In production, integrate with OpenAI, Groq, or other AI APIs
    const responses = [
      "That's a great question! As an AI assistant, I'm here to help you explore AI and machine learning concepts.",
      "I'd be happy to help with that! AI is transforming how we build applications.",
      "Interesting! Let me share some insights about that topic.",
      "That's exactly the kind of innovative thinking that drives AI forward!",
      "Great point! In the world of AI and ML, that's a crucial consideration.",
    ];

    const randomResponse =
      responses[Math.floor(Math.random() * responses.length)];

    // Simulate AI processing delay
    await new Promise((resolve) => setTimeout(resolve, 1000));

    return Response.json({
      response: `${randomResponse} You asked: "${message}". This is a demo response. In production, this would connect to a real AI model like GPT-4 or Groq.`,
    });
  } catch (error) {
    console.error("AI Chat Error:", error);
    return Response.json(
      { error: "Failed to process chat message" },
      { status: 500 },
    );
  }
}
