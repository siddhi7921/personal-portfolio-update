export async function POST(request) {
  try {
    const { resumeText } = await request.json();

    if (!resumeText || resumeText.trim().length < 50) {
      return Response.json(
        { error: "Please provide a valid resume with at least 50 characters" },
        { status: 400 },
      );
    }

    // Mock resume analysis - In production, use NLP/AI for real analysis
    const wordCount = resumeText.split(/\s+/).length;
    const hasEmail = /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/.test(
      resumeText,
    );
    const hasPhone = /\b\d{3}[-.]?\d{3}[-.]?\d{4}\b/.test(resumeText);
    const hasSkills = /skills|technologies|expertise/i.test(resumeText);
    const hasExperience = /experience|work|employment|position/i.test(
      resumeText,
    );
    const hasEducation = /education|degree|university|college/i.test(
      resumeText,
    );

    // Calculate ATS score
    let atsScore = 50;
    if (hasEmail) atsScore += 10;
    if (hasPhone) atsScore += 5;
    if (hasSkills) atsScore += 15;
    if (hasExperience) atsScore += 10;
    if (hasEducation) atsScore += 10;
    if (wordCount > 200) atsScore += 5;
    if (wordCount > 400) atsScore += 5;

    const strengths = [];
    const improvements = [];

    if (hasEmail && hasPhone) {
      strengths.push("Contact information is clearly provided");
    } else {
      improvements.push("Add complete contact information (email and phone)");
    }

    if (hasSkills) {
      strengths.push("Skills section is present");
    } else {
      improvements.push(
        "Add a dedicated skills section with relevant technologies",
      );
    }

    if (hasExperience) {
      strengths.push("Work experience is documented");
    } else {
      improvements.push("Include work experience or relevant projects");
    }

    if (hasEducation) {
      strengths.push("Educational background is mentioned");
    } else {
      improvements.push("Add your educational qualifications");
    }

    if (wordCount < 200) {
      improvements.push("Resume is too brief - aim for 300-500 words");
    } else if (wordCount > 600) {
      improvements.push("Resume is too long - keep it concise (300-500 words)");
    } else {
      strengths.push("Resume length is appropriate");
    }

    // Add AI-specific recommendations
    if (!/AI|machine learning|deep learning|neural network/i.test(resumeText)) {
      improvements.push("Highlight AI/ML skills and projects more prominently");
    }

    if (!/github|portfolio|project/i.test(resumeText)) {
      improvements.push("Include links to GitHub or portfolio projects");
    }

    // Simulate processing time
    await new Promise((resolve) => setTimeout(resolve, 2000));

    return Response.json({
      atsScore: Math.min(atsScore, 100),
      strengths:
        strengths.length > 0 ? strengths : ["Resume has basic structure"],
      improvements:
        improvements.length > 0
          ? improvements
          : ["Keep refining and updating regularly"],
    });
  } catch (error) {
    console.error("Resume Analysis Error:", error);
    return Response.json(
      { error: "Failed to analyze resume" },
      { status: 500 },
    );
  }
}
