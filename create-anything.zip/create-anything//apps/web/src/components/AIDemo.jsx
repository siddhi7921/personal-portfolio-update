"use client";

import { useState } from "react";
import { Send, Sparkles, MessageSquare, FileText } from "lucide-react";

export default function AIDemo() {
  const [activeTab, setActiveTab] = useState("chat");
  const [chatInput, setChatInput] = useState("");
  const [chatMessages, setChatMessages] = useState([]);
  const [loading, setLoading] = useState(false);

  const [emotion, setEmotion] = useState("happy");
  const [messageContext, setMessageContext] = useState("");
  const [generatedMessage, setGeneratedMessage] = useState("");

  const [resumeText, setResumeText] = useState("");
  const [resumeFeedback, setResumeFeedback] = useState(null);

  const handleChat = async () => {
    if (!chatInput.trim()) return;

    const userMessage = { role: "user", content: chatInput };
    setChatMessages((prev) => [...prev, userMessage]);
    setChatInput("");
    setLoading(true);

    try {
      const response = await fetch("/api/ai-chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: chatInput }),
      });

      if (!response.ok) throw new Error("Failed to get response");

      const data = await response.json();
      setChatMessages((prev) => [
        ...prev,
        { role: "assistant", content: data.response },
      ]);
    } catch (error) {
      console.error(error);
      setChatMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          content: "Sorry, I encountered an error. Please try again!",
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const handleGenerateMessage = async () => {
    if (!messageContext.trim()) return;
    setLoading(true);

    try {
      const response = await fetch("/api/generate-message", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ emotion, context: messageContext }),
      });

      if (!response.ok) throw new Error("Failed to generate message");

      const data = await response.json();
      setGeneratedMessage(data.message);
    } catch (error) {
      console.error(error);
      setGeneratedMessage(
        "Sorry, could not generate message. Please try again!",
      );
    } finally {
      setLoading(false);
    }
  };

  const handleAnalyzeResume = async () => {
    if (!resumeText.trim()) return;
    setLoading(true);

    try {
      const response = await fetch("/api/analyze-resume", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ resumeText }),
      });

      if (!response.ok) throw new Error("Failed to analyze resume");

      const data = await response.json();
      setResumeFeedback(data);
    } catch (error) {
      console.error(error);
      setResumeFeedback({ error: "Analysis failed. Please try again!" });
    } finally {
      setLoading(false);
    }
  };

  return (
    <section
      id="ai-demo"
      className="relative py-32 px-6 md:px-12 bg-gradient-to-b from-transparent via-blue-500/5 to-transparent"
    >
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-6xl font-space-grotesk font-bold mb-4">
            Interactive AI Demos
          </h2>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto">
            Experience AI in action — try these live demos powered by
            intelligent models
          </p>
          <div className="w-20 h-1 bg-gradient-to-r from-blue-500 to-purple-500 mx-auto mt-6"></div>
        </div>

        {/* Tab Navigation */}
        <div className="flex flex-wrap gap-4 justify-center mb-12">
          <button
            onClick={() => setActiveTab("chat")}
            className={`px-6 py-3 rounded-full font-semibold flex items-center gap-2 transition-all ${
              activeTab === "chat"
                ? "bg-gradient-to-r from-blue-500 to-purple-500 shadow-lg shadow-blue-500/50"
                : "bg-white/5 border border-white/10 hover:bg-white/10"
            }`}
          >
            <MessageSquare className="w-5 h-5" />
            AI Assistant
          </button>
          <button
            onClick={() => setActiveTab("message")}
            className={`px-6 py-3 rounded-full font-semibold flex items-center gap-2 transition-all ${
              activeTab === "message"
                ? "bg-gradient-to-r from-blue-500 to-purple-500 shadow-lg shadow-blue-500/50"
                : "bg-white/5 border border-white/10 hover:bg-white/10"
            }`}
          >
            <Sparkles className="w-5 h-5" />
            Message Generator
          </button>
          <button
            onClick={() => setActiveTab("resume")}
            className={`px-6 py-3 rounded-full font-semibold flex items-center gap-2 transition-all ${
              activeTab === "resume"
                ? "bg-gradient-to-r from-blue-500 to-purple-500 shadow-lg shadow-blue-500/50"
                : "bg-white/5 border border-white/10 hover:bg-white/10"
            }`}
          >
            <FileText className="w-5 h-5" />
            Resume Analyzer
          </button>
        </div>

        {/* Demo Content */}
        <div className="bg-white/5 backdrop-blur-md border border-white/10 rounded-3xl p-8">
          {/* AI Chat */}
          {activeTab === "chat" && (
            <div className="space-y-6">
              <div className="h-96 overflow-y-auto space-y-4 p-4 bg-black/20 rounded-2xl">
                {chatMessages.length === 0 ? (
                  <div className="h-full flex items-center justify-center text-gray-500">
                    Start a conversation with the AI assistant...
                  </div>
                ) : (
                  chatMessages.map((msg, i) => (
                    <div
                      key={i}
                      className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
                    >
                      <div
                        className={`max-w-md px-4 py-3 rounded-2xl ${
                          msg.role === "user"
                            ? "bg-blue-500 text-white"
                            : "bg-white/10 text-gray-200"
                        }`}
                      >
                        {msg.content}
                      </div>
                    </div>
                  ))
                )}
                {loading && (
                  <div className="flex justify-start">
                    <div className="bg-white/10 px-4 py-3 rounded-2xl">
                      <div className="flex gap-2">
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                        <div
                          className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                          style={{ animationDelay: "0.2s" }}
                        ></div>
                        <div
                          className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                          style={{ animationDelay: "0.4s" }}
                        ></div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
              <div className="flex gap-3">
                <input
                  type="text"
                  value={chatInput}
                  onChange={(e) => setChatInput(e.target.value)}
                  onKeyPress={(e) => e.key === "Enter" && handleChat()}
                  placeholder="Ask me anything..."
                  className="flex-1 px-6 py-4 bg-white/5 border border-white/10 rounded-full focus:outline-none focus:border-blue-500 transition-all"
                />
                <button
                  onClick={handleChat}
                  disabled={loading}
                  className="px-8 py-4 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full font-semibold flex items-center gap-2 hover:shadow-lg hover:shadow-blue-500/50 transition-all disabled:opacity-50"
                >
                  <Send className="w-5 h-5" />
                </button>
              </div>
            </div>
          )}

          {/* Message Generator */}
          {activeTab === "message" && (
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-semibold mb-3">
                  Select Emotion
                </label>
                <div className="flex flex-wrap gap-3">
                  {["happy", "sad", "excited", "professional", "romantic"].map(
                    (emo) => (
                      <button
                        key={emo}
                        onClick={() => setEmotion(emo)}
                        className={`px-6 py-2 rounded-full capitalize transition-all ${
                          emotion === emo
                            ? "bg-gradient-to-r from-pink-500 to-purple-500"
                            : "bg-white/5 border border-white/10 hover:bg-white/10"
                        }`}
                      >
                        {emo}
                      </button>
                    ),
                  )}
                </div>
              </div>
              <div>
                <label className="block text-sm font-semibold mb-3">
                  Message Context
                </label>
                <textarea
                  value={messageContext}
                  onChange={(e) => setMessageContext(e.target.value)}
                  placeholder="E.g., Birthday wish for my best friend..."
                  className="w-full px-6 py-4 bg-white/5 border border-white/10 rounded-2xl focus:outline-none focus:border-purple-500 transition-all h-32 resize-none"
                />
              </div>
              <button
                onClick={handleGenerateMessage}
                disabled={loading}
                className="w-full px-8 py-4 bg-gradient-to-r from-pink-500 to-purple-500 rounded-full font-semibold flex items-center justify-center gap-2 hover:shadow-lg hover:shadow-pink-500/50 transition-all disabled:opacity-50"
              >
                <Sparkles className="w-5 h-5" />
                Generate Message
              </button>
              {generatedMessage && (
                <div className="p-6 bg-gradient-to-br from-pink-500/10 to-purple-500/10 border border-pink-500/20 rounded-2xl">
                  <p className="text-lg leading-relaxed">{generatedMessage}</p>
                </div>
              )}
            </div>
          )}

          {/* Resume Analyzer */}
          {activeTab === "resume" && (
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-semibold mb-3">
                  Paste Your Resume Text
                </label>
                <textarea
                  value={resumeText}
                  onChange={(e) => setResumeText(e.target.value)}
                  placeholder="Paste your resume content here..."
                  className="w-full px-6 py-4 bg-white/5 border border-white/10 rounded-2xl focus:outline-none focus:border-green-500 transition-all h-48 resize-none"
                />
              </div>
              <button
                onClick={handleAnalyzeResume}
                disabled={loading}
                className="w-full px-8 py-4 bg-gradient-to-r from-green-500 to-emerald-500 rounded-full font-semibold flex items-center justify-center gap-2 hover:shadow-lg hover:shadow-green-500/50 transition-all disabled:opacity-50"
              >
                <FileText className="w-5 h-5" />
                Analyze Resume
              </button>
              {resumeFeedback && !resumeFeedback.error && (
                <div className="space-y-4">
                  <div className="p-6 bg-gradient-to-br from-green-500/10 to-emerald-500/10 border border-green-500/20 rounded-2xl">
                    <h3 className="text-xl font-semibold mb-3">
                      📊 Analysis Results
                    </h3>
                    <div className="space-y-3">
                      <div>
                        <span className="font-semibold">ATS Score:</span>{" "}
                        {resumeFeedback.atsScore}/100
                      </div>
                      <div>
                        <span className="font-semibold">Strengths:</span>
                        <ul className="list-disc list-inside mt-2 text-gray-300">
                          {resumeFeedback.strengths?.map((s, i) => (
                            <li key={i}>{s}</li>
                          ))}
                        </ul>
                      </div>
                      <div>
                        <span className="font-semibold">Improvements:</span>
                        <ul className="list-disc list-inside mt-2 text-gray-300">
                          {resumeFeedback.improvements?.map((imp, i) => (
                            <li key={i}>{imp}</li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              )}
              {resumeFeedback?.error && (
                <div className="p-6 bg-red-500/10 border border-red-500/20 rounded-2xl text-red-300">
                  {resumeFeedback.error}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
