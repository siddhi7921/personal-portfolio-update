"use client";

import { Code2, Brain, Rocket } from "lucide-react";

export default function About() {
  return (
    <section id="about" className="relative py-32 px-6 md:px-12">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-6xl font-space-grotesk font-bold mb-4">
            About Me
          </h2>
          <div className="w-20 h-1 bg-gradient-to-r from-blue-500 to-purple-500 mx-auto"></div>
        </div>

        <div className="grid lg:grid-cols-3 gap-12 items-start">
          {/* Left - Image */}
          <div className="relative group">
            <div className="absolute -inset-1 bg-gradient-to-r from-blue-500 to-purple-500 rounded-2xl blur opacity-25 group-hover:opacity-50 transition duration-1000 group-hover:duration-200"></div>
            <div className="relative aspect-[4/5] rounded-2xl overflow-hidden border border-white/10">
              <img
                src="https://ucarecdn.com/da8ff118-511c-426e-80c8-348e40178e6d/-/format/auto/"
                alt="Siddhinath Chakraborty"
                className="w-full h-full object-cover"
              />
            </div>
          </div>

          {/* Middle - Story */}
          <div className="lg:col-span-2 space-y-8">
            <div className="grid md:grid-cols-2 gap-12">
              <div className="space-y-6">
                <p className="text-lg text-gray-300 leading-relaxed">
                  I am{" "}
                  <span className="text-blue-400 font-semibold">
                    Siddhinath Chakraborty
                  </span>
                  , a Computer Science & Engineering student specializing in{" "}
                  <span className="text-purple-400 font-semibold">
                    Artificial Intelligence and Machine Learning
                  </span>{" "}
                  at{" "}
                  <span className="text-pink-400 font-semibold">
                    RCC Institute of Information Technology
                  </span>
                  .
                </p>

                <p className="text-lg text-gray-300 leading-relaxed">
                  I am passionate about building real-world AI-powered
                  applications, intelligent agents, and interactive web
                  experiences. Instead of limiting myself to theory, I focus on
                  hands-on learning by developing AI tools, automation systems,
                  and creative interfaces using modern technologies.
                </p>

                <p className="text-lg text-gray-300 leading-relaxed">
                  My goal is to grow as an AI engineer, contribute to meaningful
                  projects, secure strong internships, and build a personal
                  brand that reflects practical skills, creativity, and
                  continuous learning.
                </p>

                <p className="text-lg text-blue-400 font-bold italic">
                  "I don’t just learn AI — I build with it."
                </p>
              </div>

              {/* Right - Highlights */}
              <div className="space-y-4">
                <div className="p-6 bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl hover:bg-white/10 transition-all duration-300 group">
                  <div className="flex items-start gap-4">
                    <div className="p-3 bg-blue-500/20 rounded-xl group-hover:scale-110 transition-transform">
                      <Brain className="w-6 h-6 text-blue-400" />
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold mb-2">
                        AI Enthusiast
                      </h3>
                      <p className="text-gray-400">
                        Building intelligent systems that learn, adapt, and
                        solve real problems
                      </p>
                    </div>
                  </div>
                </div>

                <div className="p-6 bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl hover:bg-white/10 transition-all duration-300 group">
                  <div className="flex items-start gap-4">
                    <div className="p-3 bg-purple-500/20 rounded-xl group-hover:scale-110 transition-transform">
                      <Code2 className="w-6 h-6 text-purple-400" />
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold mb-2">
                        Full-Stack Developer
                      </h3>
                      <p className="text-gray-400">
                        Creating seamless experiences from frontend to backend
                        with modern tech
                      </p>
                    </div>
                  </div>
                </div>

                <div className="p-6 bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl hover:bg-white/10 transition-all duration-300 group">
                  <div className="flex items-start gap-4">
                    <div className="p-3 bg-pink-500/20 rounded-xl group-hover:scale-110 transition-transform">
                      <Rocket className="w-6 h-6 text-pink-400" />
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold mb-2">
                        Innovation Driven
                      </h3>
                      <p className="text-gray-400">
                        Constantly exploring new technologies and pushing
                        creative boundaries
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
