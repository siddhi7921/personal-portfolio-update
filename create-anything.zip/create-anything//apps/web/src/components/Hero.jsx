"use client";

import { useState, useEffect } from "react";
import { ArrowRight, Sparkles } from "lucide-react";

export default function Hero() {
  const [text, setText] = useState("");
  const fullText = "AI Engineer in the Making";

  useEffect(() => {
    let index = 0;
    const timer = setInterval(() => {
      if (index <= fullText.length) {
        setText(fullText.slice(0, index));
        index++;
      } else {
        clearInterval(timer);
      }
    }, 100);
    return () => clearInterval(timer);
  }, []);

  return (
    <section className="relative min-h-screen flex items-center justify-center px-6 md:px-12">
      <div className="max-w-7xl w-full">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="space-y-8">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-blue-500/10 border border-blue-500/20 backdrop-blur-sm">
              <Sparkles className="w-4 h-4 text-blue-400" />
              <span className="text-sm text-blue-300">
                Available for Internships
              </span>
            </div>

            <div className="space-y-4">
              <h1 className="text-5xl md:text-7xl font-space-grotesk font-bold leading-tight">
                Siddhinath Chakraborty
              </h1>
              <div className="h-20 md:h-24">
                <h2 className="text-3xl md:text-5xl font-space-grotesk font-bold bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
                  {text}
                  <span className="animate-pulse">|</span>
                </h2>
              </div>
              <p className="text-xl text-gray-400 max-w-xl">
                Building AI Agents, Intelligent Web Apps & Interactive
                Experiences using Modern AI Technologies
              </p>
              <p className="text-sm text-blue-400 font-medium">
                CSE (AIML) Student @ RCCIIT (2024–2028)
              </p>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-wrap gap-4">
              <a
                href="#ai-demo"
                className="group px-8 py-4 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full font-semibold flex items-center gap-2 hover:shadow-lg hover:shadow-blue-500/50 transition-all duration-300 hover:scale-105"
              >
                🤖 Talk to My AI Assistant
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </a>

              <a
                href="#resume"
                className="px-8 py-4 bg-white/5 backdrop-blur-sm border border-white/10 rounded-full font-semibold hover:bg-white/10 transition-all duration-300 hover:scale-105"
              >
                📄 View Resume
              </a>
            </div>

            {/* Social Links - Mobile */}
            <div className="flex flex-wrap gap-4 lg:hidden">
              <a
                href="https://linkedin.com/in/siddhinathchakraborty"
                target="_blank"
                rel="noopener noreferrer"
                className="px-6 py-3 bg-white/5 backdrop-blur-sm border border-white/10 rounded-full hover:bg-blue-500/20 hover:border-blue-500 transition-all"
              >
                🔗 LinkedIn
              </a>
              <a
                href="https://github.com/siddhinathchakraborty"
                target="_blank"
                rel="noopener noreferrer"
                className="px-6 py-3 bg-white/5 backdrop-blur-sm border border-white/10 rounded-full hover:bg-gray-500/20 hover:border-gray-500 transition-all"
              >
                💻 GitHub
              </a>
            </div>
          </div>

          {/* Right Visual */}
          <div className="relative hidden lg:block">
            <div className="relative w-full aspect-square flex items-center justify-center">
              {/* Animated Gradient Orb */}
              <div className="absolute inset-0 bg-gradient-to-br from-blue-500/30 via-purple-500/30 to-pink-500/30 rounded-full blur-3xl animate-pulse"></div>

              {/* Profile Image Container */}
              <div className="relative w-[400px] h-[400px] rounded-3xl overflow-hidden border-2 border-white/10 backdrop-blur-sm z-10 group">
                <img
                  src="https://ucarecdn.com/da8ff118-511c-426e-80c8-348e40178e6d/-/format/auto/"
                  alt="Siddhinath Chakraborty"
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0a]/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              </div>

              {/* Floating Cards */}
              <div className="absolute top-0 right-0 p-4 bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl transform hover:scale-110 transition-transform duration-300 z-20">
                <div className="text-3xl mb-2">🧠</div>
                <div className="text-sm font-semibold">AI Models</div>
              </div>

              <div className="absolute bottom-10 left-0 p-4 bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl transform hover:scale-110 transition-transform duration-300 z-20">
                <div className="text-3xl mb-2">⚡</div>
                <div className="text-sm font-semibold">Fast APIs</div>
              </div>

              <div className="absolute top-1/2 -right-10 -translate-y-1/2 p-6 bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl transform hover:scale-110 transition-transform duration-300 z-20">
                <div className="text-4xl mb-2">🚀</div>
                <div className="text-sm font-semibold">Innovation</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 border-2 border-white/20 rounded-full flex items-start justify-center p-2">
          <div className="w-1 h-2 bg-white/60 rounded-full"></div>
        </div>
      </div>
    </section>
  );
}
