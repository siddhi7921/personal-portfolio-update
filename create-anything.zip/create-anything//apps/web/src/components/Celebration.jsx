import React, { useEffect, useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Sparkles, PartyPopper } from "lucide-react";

const Celebration = () => {
  const [isVisible, setIsVisible] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(false);
    }, 4000);
    return () => clearTimeout(timer);
  }, []);

  const particles = Array.from({ length: 40 }).map((_, i) => ({
    id: i,
    x: Math.random() * 100 - 50,
    y: Math.random() * 100 - 50,
    color: ["#3b82f6", "#8b5cf6", "#ec4899", "#f59e0b", "#10b981"][
      Math.floor(Math.random() * 5)
    ],
    size: Math.random() * 8 + 4,
    delay: Math.random() * 0.5,
  }));

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[100] flex items-center justify-center pointer-events-none overflow-hidden bg-black/40 backdrop-blur-sm"
        >
          {/* Confetti Particles */}
          <div className="absolute inset-0 flex items-center justify-center">
            {particles.map((p) => (
              <motion.div
                key={p.id}
                initial={{ x: 0, y: 0, scale: 0, opacity: 1 }}
                animate={{
                  x: p.x * 10,
                  y: p.y * 10,
                  scale: [0, 1, 0.5],
                  opacity: [1, 1, 0],
                  rotate: [0, 180, 360],
                }}
                transition={{
                  duration: 2.5,
                  delay: p.delay,
                  ease: "easeOut",
                }}
                style={{
                  position: "absolute",
                  width: p.size,
                  height: p.size,
                  backgroundColor: p.color,
                  borderRadius: Math.random() > 0.5 ? "50%" : "2px",
                }}
              />
            ))}
          </div>

          {/* Welcome Message */}
          <motion.div
            initial={{ scale: 0.5, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 1.2, opacity: 0, y: -20 }}
            transition={{ type: "spring", damping: 12, stiffness: 100 }}
            className="relative bg-white/10 backdrop-blur-md border border-white/20 p-8 rounded-3xl text-center shadow-2xl"
          >
            <div className="flex justify-center gap-4 mb-4">
              <motion.div
                animate={{ rotate: [0, 20, -20, 0] }}
                transition={{ repeat: Infinity, duration: 1.5 }}
              >
                <PartyPopper className="w-10 h-10 text-yellow-400" />
              </motion.div>
              <motion.div
                animate={{ scale: [1, 1.2, 1] }}
                transition={{ repeat: Infinity, duration: 2 }}
              >
                <Sparkles className="w-10 h-10 text-blue-400" />
              </motion.div>
            </div>

            <h2 className="text-4xl font-bold bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent mb-2">
              Welcome to My Portfolio!
            </h2>
            <p className="text-gray-300 text-lg">
              Exploring the future of AI & ML
            </p>

            <motion.div
              initial={{ width: 0 }}
              animate={{ width: "100%" }}
              transition={{ duration: 3, ease: "linear" }}
              className="h-1 bg-gradient-to-r from-blue-500 to-purple-500 mt-6 rounded-full opacity-50"
            />
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default Celebration;
