"use client";

const skills = [
  {
    name: "Python",
    icon: "🐍",
    level: 90,
    color: "from-yellow-500 to-blue-500",
  },
  { name: "Java", icon: "☕", level: 85, color: "from-red-500 to-orange-500" },
  {
    name: "Artificial Intelligence",
    icon: "🧠",
    level: 88,
    color: "from-purple-500 to-pink-500",
  },
  {
    name: "Machine Learning",
    icon: "🤖",
    level: 85,
    color: "from-blue-500 to-purple-500",
  },
  {
    name: "Prompt Engineering",
    icon: "✍️",
    level: 92,
    color: "from-pink-500 to-rose-500",
  },
  { name: "React", icon: "⚛️", level: 92, color: "from-cyan-500 to-blue-500" },
  {
    name: "Tailwind CSS",
    icon: "🎨",
    level: 95,
    color: "from-blue-400 to-cyan-400",
  },
  {
    name: "Three.js",
    icon: "🌐",
    level: 80,
    color: "from-green-500 to-teal-500",
  },
  {
    name: "Git & GitHub",
    icon: "📦",
    level: 90,
    color: "from-gray-500 to-gray-700",
  },
  { name: "APIs", icon: "🔌", level: 87, color: "from-blue-500 to-indigo-500" },
  {
    name: "AI Agents",
    icon: "🕵️",
    level: 82,
    color: "from-indigo-500 to-purple-500",
  },
  {
    name: "Automation",
    icon: "⚙️",
    level: 85,
    color: "from-orange-500 to-red-500",
  },
];

export default function Skills() {
  return (
    <section id="skills" className="relative py-32 px-6 md:px-12">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-6xl font-space-grotesk font-bold mb-4">
            Skills & Technologies
          </h2>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto">
            A diverse toolkit for building intelligent, scalable applications
          </p>
          <div className="w-20 h-1 bg-gradient-to-r from-blue-500 to-purple-500 mx-auto mt-6"></div>
        </div>

        {/* Skills Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {skills.map((skill, index) => (
            <div
              key={index}
              className="group relative p-6 bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl hover:bg-white/10 transition-all duration-300 hover:scale-105"
            >
              {/* Skill Icon */}
              <div className="text-5xl mb-4 group-hover:scale-110 transition-transform">
                {skill.icon}
              </div>

              {/* Skill Name */}
              <h3 className="text-xl font-semibold mb-3">{skill.name}</h3>

              {/* Progress Bar */}
              <div className="relative h-2 bg-white/10 rounded-full overflow-hidden">
                <div
                  className={`absolute inset-y-0 left-0 bg-gradient-to-r ${skill.color} rounded-full transition-all duration-1000 ease-out`}
                  style={{ width: `${skill.level}%` }}
                ></div>
              </div>

              {/* Level Percentage */}
              <div className="mt-2 text-sm text-gray-400 text-right">
                {skill.level}%
              </div>
            </div>
          ))}
        </div>

        {/* Additional Info */}
        <div className="mt-16 grid md:grid-cols-3 gap-8">
          <div className="text-center p-8 bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl">
            <div className="text-4xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent mb-2">
              15+
            </div>
            <div className="text-gray-400">Projects Completed</div>
          </div>

          <div className="text-center p-8 bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl">
            <div className="text-4xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent mb-2">
              5+
            </div>
            <div className="text-gray-400">AI Models Deployed</div>
          </div>

          <div className="text-center p-8 bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl">
            <div className="text-4xl font-bold bg-gradient-to-r from-pink-400 to-red-400 bg-clip-text text-transparent mb-2">
              1000+
            </div>
            <div className="text-gray-400">Lines of Code</div>
          </div>
        </div>
      </div>
    </section>
  );
}
