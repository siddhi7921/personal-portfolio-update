"use client";

import { ExternalLink, Github } from "lucide-react";

const projects = [
  {
    title: "AI Personal Assistant – Sitara",
    description:
      "A personal AI assistant designed to answer questions, generate content, and assist users through natural conversations. Built with a scalable architecture for future personalization.",
    tech: ["React", "Node.js", "GPT-5.1", "API Integration"],
    gradient: "from-blue-500 to-cyan-500",
    icon: "🤖",
    demo: "#ai-demo",
    github: "#",
  },
  {
    title: "Gesture-Controlled Particle Art",
    description:
      "An interactive Three.js visual experience where hand gestures dynamically control particle motion, colors, and shapes such as hearts, fireworks, and planetary forms.",
    tech: ["Three.js", "WebGL", "React", "Gesture Analysis"],
    gradient: "from-purple-500 to-pink-500",
    icon: "✨",
    demo: "#",
    github: "#",
  },
  {
    title: "Emotional Message Generator",
    description:
      "An AI-powered tool that generates heartfelt emotional messages for proposals, birthdays, and special moments with cinematic tone and personalization.",
    tech: ["React", "AI Text Generation", "Prompt Engineering"],
    gradient: "from-pink-500 to-rose-500",
    icon: "💌",
    demo: "#ai-demo",
    github: "#",
  },
  {
    title: "AI Resume Analyzer",
    description:
      "An intelligent resume review tool that analyzes resumes and provides improvement suggestions for structure, keywords, and clarity.",
    tech: ["AI NLP", "Resume Parsing", "React UI"],
    gradient: "from-green-500 to-emerald-500",
    icon: "📄",
    demo: "#ai-demo",
    github: "#",
  },
  {
    title: "Instagram Caption Generator",
    description:
      "An AI tool that creates engaging Instagram captions based on mood, topic, and audience type to improve reach and engagement.",
    tech: ["AI Content Generation", "Frontend UI"],
    gradient: "from-orange-500 to-yellow-500",
    icon: "📸",
    demo: "#",
    github: "#",
  },
];

export default function Projects() {
  return (
    <section id="projects" className="relative py-32 px-6 md:px-12">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-6xl font-space-grotesk font-bold mb-4">
            AI Projects
          </h2>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto">
            Real-world applications showcasing AI, machine learning, and
            creative coding
          </p>
          <div className="w-20 h-1 bg-gradient-to-r from-blue-500 to-purple-500 mx-auto mt-6"></div>
        </div>

        {/* Bento Grid Layout */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.map((project, index) => (
            <div
              key={index}
              className="group relative p-6 bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl hover:bg-white/10 transition-all duration-300 hover:scale-105 hover:shadow-2xl"
            >
              {/* Gradient Accent */}
              <div
                className={`absolute inset-0 bg-gradient-to-br ${project.gradient} opacity-0 group-hover:opacity-10 rounded-2xl transition-opacity duration-300`}
              ></div>

              {/* Content */}
              <div className="relative z-10">
                <div className="text-5xl mb-4">{project.icon}</div>

                <h3 className="text-2xl font-space-grotesk font-bold mb-3">
                  {project.title}
                </h3>

                <p className="text-gray-400 mb-4 leading-relaxed">
                  {project.description}
                </p>

                {/* Tech Stack */}
                <div className="flex flex-wrap gap-2 mb-6">
                  {project.tech.map((tech, i) => (
                    <span
                      key={i}
                      className="px-3 py-1 text-xs bg-white/10 border border-white/20 rounded-full text-gray-300"
                    >
                      {tech}
                    </span>
                  ))}
                </div>

                {/* Action Buttons */}
                <div className="flex gap-3">
                  <a
                    href={project.demo}
                    className="flex-1 px-4 py-2 bg-gradient-to-r from-blue-500 to-purple-500 rounded-lg font-semibold text-sm flex items-center justify-center gap-2 hover:shadow-lg hover:shadow-blue-500/50 transition-all"
                  >
                    <ExternalLink className="w-4 h-4" />
                    Demo
                  </a>
                  <a
                    href={project.github}
                    className="px-4 py-2 bg-white/10 border border-white/20 rounded-lg font-semibold text-sm flex items-center justify-center gap-2 hover:bg-white/20 transition-all"
                  >
                    <Github className="w-4 h-4" />
                    Code
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
