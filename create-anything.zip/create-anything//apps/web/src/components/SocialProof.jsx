"use client";

import { Linkedin, Instagram, Award } from "lucide-react";

const linkedinPosts = [
  {
    title: "Building AI Agents with LangChain",
    excerpt:
      "Just deployed my first autonomous AI agent that can handle customer queries...",
    likes: 234,
    comments: 45,
  },
  {
    title: "My Journey into Machine Learning",
    excerpt:
      "From zero to building production ML models - here's what I learned...",
    likes: 189,
    comments: 32,
  },
  {
    title: "Three.js + AI: The Future of Web",
    excerpt:
      "Combining 3D graphics with AI creates mind-blowing interactive experiences...",
    likes: 312,
    comments: 58,
  },
];

const instagramReels = [
  {
    title: "AI Assistant Demo",
    views: "12.5K",
    thumbnail: "🤖",
  },
  {
    title: "Gesture Control Art",
    views: "18.2K",
    thumbnail: "✨",
  },
  {
    title: "Code Walkthrough",
    views: "9.8K",
    thumbnail: "💻",
  },
];

const certificates = [
  {
    name: "Machine Learning Specialization",
    issuer: "Stanford Online",
    icon: "🎓",
  },
  { name: "Deep Learning with TensorFlow", issuer: "Google", icon: "🧠" },
  { name: "Full Stack Web Development", issuer: "freeCodeCamp", icon: "🌐" },
];

export default function SocialProof() {
  return (
    <section
      id="social-proof"
      className="relative py-32 px-6 md:px-12 bg-gradient-to-b from-transparent via-purple-500/5 to-transparent"
    >
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-6xl font-space-grotesk font-bold mb-4">
            Social Proof
          </h2>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto">
            Building in public and sharing knowledge with the community
          </p>
          <div className="w-20 h-1 bg-gradient-to-r from-blue-500 to-purple-500 mx-auto mt-6"></div>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* LinkedIn Posts */}
          <div>
            <div className="flex items-center gap-3 mb-6">
              <Linkedin className="w-8 h-8 text-blue-400" />
              <h3 className="text-2xl font-space-grotesk font-bold">
                LinkedIn Posts
              </h3>
            </div>
            <div className="space-y-4">
              {linkedinPosts.map((post, index) => (
                <div
                  key={index}
                  className="p-6 bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl hover:bg-white/10 transition-all duration-300 group cursor-pointer"
                >
                  <h4 className="text-lg font-semibold mb-2 group-hover:text-blue-400 transition-colors">
                    {post.title}
                  </h4>
                  <p className="text-gray-400 mb-4">{post.excerpt}</p>
                  <div className="flex gap-6 text-sm text-gray-500">
                    <span>👍 {post.likes} likes</span>
                    <span>💬 {post.comments} comments</span>
                  </div>
                </div>
              ))}
            </div>
            <a
              href="https://linkedin.com/in/yourprofile"
              target="_blank"
              rel="noopener noreferrer"
              className="mt-6 inline-flex items-center gap-2 px-6 py-3 bg-blue-500/20 border border-blue-500/30 rounded-full hover:bg-blue-500/30 transition-all"
            >
              <Linkedin className="w-5 h-5" />
              View All Posts
            </a>
          </div>

          {/* Instagram Reels */}
          <div>
            <div className="flex items-center gap-3 mb-6">
              <Instagram className="w-8 h-8 text-pink-400" />
              <h3 className="text-2xl font-space-grotesk font-bold">
                Instagram Reels
              </h3>
            </div>
            <div className="grid grid-cols-3 gap-4 mb-6">
              {instagramReels.map((reel, index) => (
                <div
                  key={index}
                  className="aspect-[9/16] bg-gradient-to-br from-pink-500/20 to-purple-500/20 border border-white/10 rounded-2xl flex flex-col items-center justify-center hover:scale-105 transition-transform cursor-pointer group"
                >
                  <div className="text-5xl mb-3 group-hover:scale-110 transition-transform">
                    {reel.thumbnail}
                  </div>
                  <div className="text-xs text-gray-400">
                    {reel.views} views
                  </div>
                </div>
              ))}
            </div>
            <div className="p-6 bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl">
              <p className="text-gray-400 mb-4">
                Follow for daily AI tips, project demos, and coding tutorials
              </p>
              <a
                href="https://instagram.com/yourprofile"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-pink-500 to-purple-500 rounded-full hover:shadow-lg hover:shadow-pink-500/50 transition-all"
              >
                <Instagram className="w-5 h-5" />
                Follow on Instagram
              </a>
            </div>
          </div>
        </div>

        {/* Certificates */}
        <div className="mt-16">
          <div className="flex items-center gap-3 mb-6">
            <Award className="w-8 h-8 text-yellow-400" />
            <h3 className="text-2xl font-space-grotesk font-bold">
              Certifications
            </h3>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {certificates.map((cert, index) => (
              <div
                key={index}
                className="p-6 bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl hover:bg-white/10 transition-all duration-300 hover:scale-105"
              >
                <div className="text-4xl mb-4">{cert.icon}</div>
                <h4 className="text-lg font-semibold mb-2">{cert.name}</h4>
                <p className="text-sm text-gray-400">{cert.issuer}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
