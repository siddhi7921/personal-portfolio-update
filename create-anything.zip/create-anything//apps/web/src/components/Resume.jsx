"use client";

import {
  Mail,
  MapPin,
  Linkedin,
  Github,
  ExternalLink,
  Download,
  FileText,
} from "lucide-react";

export default function Resume() {
  const resumeData = {
    name: "SIDDHINATH CHAKRABORTY",
    role: "CSE (Artificial Intelligence & Machine Learning) Student",
    location: "West Bengal, India",
    email: "siddhinathchakraborty@gmail.com",
    linkedin: "https://linkedin.com/in/siddhinathchakraborty",
    github: "https://github.com/siddhinathchakraborty",
    portfolio: "https://your-portfolio-link.vercel.app",
    summary:
      "Highly motivated Computer Science & Engineering student specializing in Artificial Intelligence and Machine Learning, with a strong focus on building real-world AI-powered applications. Experienced in developing AI assistants, intelligent web tools, and interactive 3D experiences using modern technologies. Passionate about hands-on learning, automation, and creating impactful AI products rather than limiting learning to theory. Actively building a strong personal brand through projects and experimentation.",
    education: {
      degree: "Bachelor of Technology (B.Tech)",
      major:
        "Computer Science & Engineering (Artificial Intelligence & Machine Learning)",
      school: "RCC Institute of Information Technology (RCCIIT), West Bengal",
      duration: "2024 – 2028",
    },
    skills: {
      languages: ["Python", "Java"],
      ai_ml: [
        "Artificial Intelligence Fundamentals",
        "Machine Learning Concepts",
        "Prompt Engineering",
        "AI Agents & LLM-based Systems",
      ],
      web: ["React.js", "Tailwind CSS", "HTML, CSS, JavaScript"],
      interactive: [
        "Three.js",
        "WebGL (Basics)",
        "Gesture-Based Interaction Systems",
      ],
      tools: ["Git & GitHub", "REST APIs", "Vercel Deployment"],
    },
    projects: [
      {
        title: "AI Personal Assistant – Sitara",
        description:
          "Developed a conversational AI assistant capable of answering queries, generating content, and assisting users in real time. Designed with a scalable, API-ready architecture for future personalization and feature expansion.",
        tech: "React, Node.js, OpenAI GPT-5.1 (Emergent LLM), API Integration",
      },
      {
        title: "Gesture-Controlled Particle Art",
        description:
          "Built an interactive Three.js experience where hand gestures dynamically control particle movement, colors, and shapes such as hearts, fireworks, and planetary visuals.",
        tech: "Three.js, React, WebGL, Gesture Analysis",
      },
      {
        title: "Emotional Message Generator",
        description:
          "Created an AI-powered tool that generates personalized emotional messages for proposals, birthdays, and special occasions.",
        tech: "AI Text Generation, Prompt Engineering, React",
      },
      {
        title: "AI Resume Analyzer",
        description:
          "Developed an AI-based resume review tool that analyzes resumes and provides improvement suggestions related to structure, keywords, and clarity.",
        tech: "AI NLP, Resume Parsing, Frontend UI",
      },
    ],
    interests: [
      "Artificial Intelligence & Automation",
      "AI Agents & Intelligent Systems",
      "Creative Coding & Interactive Visual Design",
      "Personal Branding & Tech Content Creation",
    ],
  };

  return (
    <section
      id="resume"
      className="py-24 px-6 md:px-12 bg-white/5 backdrop-blur-sm"
    >
      <div className="max-w-5xl mx-auto">
        <div className="flex flex-col md:flex-row gap-12 items-start">
          {/* Left Column: Profile & Contact */}
          <div className="w-full md:w-1/3 space-y-8">
            <div className="relative group">
              <div className="absolute -inset-1 bg-gradient-to-r from-blue-500 to-purple-500 rounded-2xl blur opacity-25 group-hover:opacity-50 transition duration-1000 group-hover:duration-200"></div>
              <div className="relative aspect-square rounded-2xl overflow-hidden border border-white/10">
                <img
                  src="https://ucarecdn.com/da8ff118-511c-426e-80c8-348e40178e6d/-/format/auto/"
                  alt={resumeData.name}
                  className="w-full h-full object-cover"
                />
              </div>
            </div>

            <div className="space-y-4">
              <h2 className="text-2xl font-bold font-space-grotesk">
                {resumeData.name}
              </h2>
              <p className="text-blue-400 font-medium text-sm">
                {resumeData.role}
              </p>

              <div className="space-y-3 pt-4">
                <div className="flex items-center gap-3 text-gray-400 hover:text-white transition-colors">
                  <MapPin className="w-4 h-4 text-blue-400" />
                  <span className="text-sm">{resumeData.location}</span>
                </div>
                <a
                  href={`mailto:${resumeData.email}`}
                  className="flex items-center gap-3 text-gray-400 hover:text-white transition-colors"
                >
                  <Mail className="w-4 h-4 text-blue-400" />
                  <span className="text-sm">{resumeData.email}</span>
                </a>
                <a
                  href={resumeData.linkedin}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-3 text-gray-400 hover:text-white transition-colors"
                >
                  <Linkedin className="w-4 h-4 text-blue-400" />
                  <span className="text-sm">LinkedIn Profile</span>
                </a>
                <a
                  href={resumeData.github}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-3 text-gray-400 hover:text-white transition-colors"
                >
                  <Github className="w-4 h-4 text-blue-400" />
                  <span className="text-sm">GitHub Profile</span>
                </a>
              </div>
            </div>

            <div className="pt-8">
              <button className="w-full py-4 bg-white/5 border border-white/10 rounded-xl font-semibold flex items-center justify-center gap-2 hover:bg-white/10 transition-all group">
                <Download className="w-5 h-5 group-hover:translate-y-1 transition-transform" />
                Download PDF Resume
              </button>
            </div>
          </div>

          {/* Right Column: Content */}
          <div className="w-full md:w-2/3 space-y-12">
            {/* Summary */}
            <div className="space-y-4">
              <div className="flex items-center gap-2 text-blue-400">
                <FileText className="w-5 h-5" />
                <h3 className="text-lg font-bold uppercase tracking-wider">
                  Professional Summary
                </h3>
              </div>
              <p className="text-gray-400 leading-relaxed">
                {resumeData.summary}
              </p>
            </div>

            {/* Education */}
            <div className="space-y-4">
              <div className="flex items-center gap-2 text-purple-400">
                <div className="w-5 h-5 flex items-center justify-center">
                  🎓
                </div>
                <h3 className="text-lg font-bold uppercase tracking-wider">
                  Education
                </h3>
              </div>
              <div className="p-6 bg-white/5 border border-white/10 rounded-2xl space-y-2">
                <h4 className="text-xl font-bold">
                  {resumeData.education.degree}
                </h4>
                <p className="text-blue-400 font-medium">
                  {resumeData.education.major}
                </p>
                <p className="text-gray-400">{resumeData.education.school}</p>
                <p className="text-sm text-gray-500">
                  {resumeData.education.duration}
                </p>
              </div>
            </div>

            {/* Skills */}
            <div className="space-y-6">
              <div className="flex items-center gap-2 text-pink-400">
                <div className="w-5 h-5 flex items-center justify-center">
                  💻
                </div>
                <h3 className="text-lg font-bold uppercase tracking-wider">
                  Technical Skills
                </h3>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                {Object.entries(resumeData.skills).map(([key, skills]) => (
                  <div key={key} className="space-y-3">
                    <h4 className="text-sm font-bold text-gray-500 uppercase tracking-widest">
                      {key.replace("_", " & ")}
                    </h4>
                    <div className="flex flex-wrap gap-2">
                      {skills.map((skill) => (
                        <span
                          key={skill}
                          className="px-3 py-1 bg-white/5 border border-white/10 rounded-full text-xs text-gray-300"
                        >
                          {skill}
                        </span>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Projects */}
            <div className="space-y-6">
              <div className="flex items-center gap-2 text-blue-400">
                <div className="w-5 h-5 flex items-center justify-center">
                  🚀
                </div>
                <h3 className="text-lg font-bold uppercase tracking-wider">
                  Key Projects
                </h3>
              </div>
              <div className="space-y-6">
                {resumeData.projects.map((project) => (
                  <div
                    key={project.title}
                    className="group p-6 bg-white/5 border border-white/10 rounded-2xl hover:bg-white/10 transition-all"
                  >
                    <div className="flex justify-between items-start mb-2">
                      <h4 className="text-xl font-bold group-hover:text-blue-400 transition-colors">
                        {project.title}
                      </h4>
                      <ExternalLink className="w-4 h-4 text-gray-500" />
                    </div>
                    <p className="text-gray-400 text-sm mb-4 leading-relaxed">
                      {project.description}
                    </p>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-bold text-blue-500 uppercase tracking-widest">
                        Stack:
                      </span>
                      <span className="text-xs text-gray-500">
                        {project.tech}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
